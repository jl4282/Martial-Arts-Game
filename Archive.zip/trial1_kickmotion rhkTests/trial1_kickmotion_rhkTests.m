//
//  trial1_kickmotion_rhkTests.m
//  trial1_kickmotion rhkTests
//
//  Created by Kwang-Jae Chang on 3/22/14.
//  Copyright (c) 2014 nyu.edu. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface trial1_kickmotion_rhkTests : XCTestCase

@end

@implementation trial1_kickmotion_rhkTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
