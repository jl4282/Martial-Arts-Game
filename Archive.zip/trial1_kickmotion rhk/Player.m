//
//  Player.m
//  trial1_kickmotion rhk
//
//  Created by Jesse Lifshitz on 3/26/14.
//  Copyright (c) 2014 nyu.edu. All rights reserved.
//

#import "Player.h"

//Keeps track of player stats

@implementation Player

@synthesize health;
@synthesize location;
@synthesize stamina;
@synthesize stance;
@synthesize animation;
@end
