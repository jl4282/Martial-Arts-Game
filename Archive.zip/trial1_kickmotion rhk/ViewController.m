//
//  ViewController.m
//  trial1_kickmotion rhk
//
//  Created by Kwang-Jae Chang on 3/22/14.
//  Copyright (c) 2014 nyu.edu. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController



-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    
}



- (IBAction)next:(id)sender {
}




@end
